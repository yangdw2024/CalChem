# 文件级任务与依赖图（v0.3.0 → v1.0）

每个任务都包含目标文件、目标函数签名、动作和可核验验收。签名是实施契约：旧调用方必须有兼容层或迁移测试。任务编号顺序是默认执行顺序。表中 `前置` 已明确依赖；标记 `轻并` 的只有文档、GUI 视图或 parser fixture 等轻量工作可由不同开发者并行写代码，**所有重计算与外部程序验收仍严格串行**。本地 agent 可以完全按编号顺序执行，不需要询问用户任务顺序。

## v0.3.0：先纠正科学结果和调度，再稳定外部后端

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与“假通过”防线 |
|---|---|---|---|
| 3.01/无 | `pyproject.toml`; `[project.scripts] calchem=calchem.cli:cli` | 从完整本地仓库恢复并整理安装元数据；core/gui/external/pyscf/dev extras；`norecursedirs` 排除历史 debug/scratch | 非 C 盘 venv `pip install -e .` 后 CLI 可启动。只检查源码存在不算安装通过 |
| 3.02/3.01 | `tests/posthf/test_regression.py`; `test_h2() -> None` 等 | 把打印/布尔返回改成 `assert abs(E-ref)<阈值`；每个参考几何、单位、method/basis、来源单独 fixture；Ne/CH3/O2 标注已验证范围 | 故意扰动一个 ref 时 pytest 非零退出；恢复 ref 后绿。不得调宽阈值“修复”失败 |
| 3.03/3.01 | `tests/acceptance.py` 或 `tests/release/test_acceptance.py`; `main() -> int` | 移除 `x is None or is not None`、`or True`；所有 FAIL 导致非零退出；外部程序缺失为 BLOCKED，保留日志证据 | 注入无效 schema、坏 backend 和坏 JSON 时失败；真 Windows 运行才记 external PASS |
| 3.04/3.01 | `config/loader.py`; `load_config(config_path: Optional[Path]=None, project: Optional[Path]=None, overrides: Optional[dict]=None) -> AppConfig`; `api/service.py:__init__(config: Optional[AppConfig]=None)` | 配置实际注入 TaskService；优先级 CLI>project>user>auto>default；数据/配置/缓存非 C 盘；配置解析错误显式报 | 改配置中的 executable 和 data_root 后，`doctor`/真实任务读取相同值；错误 JSON 不静默吞掉 |
| 3.05/3.04 | `jobs/global_lock.py`; `acquire_heavy_lock(path: Path, job_id: str, timeout: float) -> ContextManager[LockOwner]` | Windows `msvcrt.locking` + Linux CI `fcntl`；锁持有全程，旁写 PID/时间诊断；锁路径全局统一 | GUI 和 CLI 两个进程同时提交，真实峰值 heavy 任务为 1；杀死持锁进程后另一个可恢复。PID 不能代替 OS 锁 |
| 3.06/3.05 | `jobs/dispatcher.py`; `submit(request: CalculationRequest)->Job`, `run_now(request: CalculationRequest)->Result`; `api/service.py:run/submit` | 合并 TaskService 的 Queue 与 Dispatcher；同步/异步走同一个全局锁和持久化 store；`finally` 释放锁；结果回写 Job 状态 | 两个提交都实际执行，第二项不丢；一个异常后下一项运行；直接 API `run` 也不能绕锁 |
| 3.07/3.04 | `backends/external.py`; `execute(cmd: Sequence[str], cwd: Path, env: Mapping, timeout: float)->ProcessOutcome` | Gaussian/ORCA/xTB 全部调用此路径；stdout/stderr 写文件流，超时终止进程树并等待退出，保存退出码 | 用轻量假程序做超时/错误码/超大输出测试；原 Gaussian/ORCA adapter 不再含独立 `subprocess.run` |
| 3.08/3.07 | `backends/parsers/gaussian.py`, `backends/parsers/orca.py`; `parse_single_point(log: Path, method: MethodSpec)->ParsedResult` | 读真实 G16 A.03/ORCA 6.1.1 fixtures；cclib 提取稳定属性（坐标、MO、频率等），终止/收敛/方法最终能留专有验证；多 job 日志取最后完成任务 | HF、DFT、MP2、CCSD(T) 能量分别对照原始 log；0 退出码但未收敛必须失败；缺最终能不能拿 SCF 冒充 |
| 3.09/3.08 | `backends/gaussian.py`, `backends/orca.py`; `single_point(request)->Result`; `core/result.py:actual_method` | 拒绝 `wb97xd→wB97X-D4` 静默替换；保存请求/实际 method；读最后有效能量；状态要求 return code、正常结束、收敛及最终字段 | 同一 H2O、同一实际方法基组串行重跑；不同方法不能仅因都有数值而被称为一致 |
| 3.10/3.04 | `core/periodic_table.py`, `core/request.py`; `MoleculeSpec._validate_consistency()` | 从唯一 Z 表验证元素/电子数；每原子 Å 坐标、有限数、multiplicity、同位素质量；native basis 支持另查 | Pa 以后元素不会被算作 0 电子；不支持 native 基组被能力层拒绝 |
| 3.11/3.01,3.09 | `backends/pyscf.py`; `single_point(request)->Result`, `capabilities()->BackendCapabilities` | 继承 `Calculator`，延迟导入；先实现已验收的 RHF/UHF/RKS/UKS 中子集；SCF/总能/轨道 alpha-beta 映射 | 未装包时 core 可导入；安装后 H2O 真运行；capability 不列未实现 Optimize |
| 3.12/3.07,3.09 | `backends/xtb.py`; `single_point(request)->Result` | 配置 binary，GFN2-xTB 单点，读精确输出，保存 stdout/stderr；GFN1/GFN-FF 未验收时不列 | 缺 binary disabled；装了 binary 但 parser 失败也不能 success |
| 3.13/3.04 | `backends/rest.py`; `capabilities()->BackendCapabilities` | 收集真实 REST 量化程序协议；若无规范保留 disabled，REST-agent 接口另在 `api/agent_tools.py` | 不以 URL 字符串存在宣称后端可用；无真实接口不做伪造网络请求 |
| 3.14/3.06,3.09,3.11,3.12 | `tests/parser/`, `tests/external/`, `docs/backends.md` | 汇总每个后端已实现的任务方法基组组合和实测版本；parser fixtures 脱敏并记录来源 | 能力表、CLI、GUI、README 同步；外部真运行一项一项串行完成 |

**阶段验收：** `3.02`、`3.03` 的故意失败检验成立；跨进程峰值 heavy 并发为 1；三后端单点与真实日志可追溯；PySCF/xTB 只显示真已实现能力。可并行轻量工作：3.10 和 3.01 的文档补充；3.11 与 3.12 的代码在公共契约稳定后可独立写，但真实计算串行。

## v0.4.0：几何优化

**决策：** native 先用中心差分梯度建立可对照的正确性基线；对 `grad/analytical.py` 的 RHF 解析梯度做逐坐标差分对照后再打开 fast path。`opt/bfgs.py` 现有 `optimize()` 调 SciPy BFGS，而 `step()` 有另一套未使用的 BFGS 实现；保留一个权威优化器路径，删除或标记内部遗留 step，避免两套语义。

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 4.01/3.10 | `grad/finite_difference.py`; `central_gradient(energy_fn: Callable, mol: Molecule, step_bohr: float)->np.ndarray` | 先转 bohr，正负扰动重建分子并检查每次 SCF 收敛；梯度输出 Eh/Bohr；针对步长做收敛检查 | H2/H2O 各坐标与外部程序梯度对照；平移方向净梯度近零；输入 Å 不被误作 bohr |
| 4.02/4.01 | `grad/analytical.py`, `grad/hf_grad.py`, `grad/dft_grad.py`; `gradient(mf, mode: Literal['analytic','numeric'])->GradientResult` | 修当前硬写 `units='bohr'`；解析 RHF 与数值对照；DFT 若未验证则数值 fallback 明示耗时 | 解析/数值差按预定方法阈值，不一致时禁用解析而非静默 fallback 成功 |
| 4.03/4.01 | `opt/bfgs.py`, `opt/optimizer.py`; `minimize_geometry(mol, energy_gradient, settings)->OptimizationOutcome` | 统一 SciPy BFGS 路径；线搜索/最大步/阈值；每步坐标、能量、梯度和失败原因保存；原子顺序不变 | 扰动 H2O 收敛；最终梯度、键长、能量趋势满足预先登记参考；达到 maxiter 为 not_converged |
| 4.04/4.02,4.03 | `backends/native.py`; `optimize(request)->Result`; `core/result.py:optimization_history` | 仅对已验证 RHF/STO-3G 首先开放；Result 保存最终 MoleculeSpec、轨迹与优化状态 | API/CLI 读写结果 round-trip；不能用初始几何或最后一步能量冒充成功 |
| 4.05/3.08 | `backends/gaussian.py`, `backends/orca.py`, `backends/parsers/*`; `optimize(request)->Result` | 生成 Opt job，解析最终优化几何、梯度/步骤/最终能，检查真正优化收敛；资源和日志沿用 external | H2O 同一初始几何在 G16/ORCA 真运行；坐标顺序、单位和最终状态一致 |
| 4.06/4.04,4.05 | `tests/opt/`, `docs/methods/optimization.md` | 设优化参考几何/能量/梯度、失败和近线性案例；每方法注明使用的梯度路径 | 单元和真实外部 Opt 串行；用户看得到数值/解析梯度来源 |

**阶段验收：** native RHF/H2O、Gaussian/ORCA Opt 真跑；仅通过单点不算优化完成。可并行轻量工作：4.05 输入模板与 4.01 解析/数值梯度代码；实际运行串行。

## v0.5.0：频率、Hessian 与 IR

**决策：** 暂不信任现有 `vib/frequency.py` 的数值。其 `self.multiplicity` 未定义、硬写 bohr、负本征值截零且热化学公式未经验证。先从已验证梯度做中心差分 Hessian；频率要投影 3 个平移与线性分子 2 个/非线性 3 个转动自由度。虚频保留符号并标记；IR 强度只有在真实解析或经验证的偶极导数可用时展示。

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 5.01/4.02 | `vib/hessian.py`; `numerical_hessian(gradient_fn, mol, step_bohr)->np.ndarray` | bohr 坐标中心差分梯度，矩阵对称化、记录每位移 SCF 状态和步长；失败位移中止 | H2O Hessian 对称、步长收敛；无单位混用；缺一次梯度不能生成“完整”Hessian |
| 5.02/5.01 | `vib/modes.py`; `project_external_modes(hessian, masses_amu, coords_bohr)->ModeResult` | 质心平移、惯量主轴、Gram-Schmidt 或 SVD 投影，质量加权对角化；线性/非线性/单原子分支 | H2 与 H2O 的振动自由度正确；转/平移残差可报告；负特征值产生虚频 |
| 5.03/5.02 | `vib/frequency.py`; `frequency_analysis(mf, settings)->FrequencyOutcome` | 替换旧内核路径；频率转换 cm⁻¹、normal modes、同位素质量；旧热化学计算先禁用，另立物理常数与单位检查 | H2O/H2 频率与独立 G16/ORCA 预定义容差比对；虚频不能被裁成 0 |
| 5.04/3.08 | `backends/gaussian.py`, `backends/orca.py`; `frequency(request)->Result` | 生成 Freq/NumFreq 或 AnFreq，解析频率、模式、IR 强度、最终几何；记录数值/解析 Hessian 方法 | 真实小分子 log、频率模式数、强度单位/方法匹配；不从别的 job 片段误取 |
| 5.05/5.03,5.04 | `core/result.py`, `gui/results/frequency_tab.py`; `set_result(result: Result)->None` | 标准化 `frequencies_cm1`、normal_modes、`ir_intensities_km_mol`，保留单位和来源；无 IR 时空状态 | JSON/UI/CSV 一致；没有 IR 强度不绘 IR 棒谱 |
| 5.06/5.03 | `tests/vib/`, `docs/methods/frequencies.md` | 投影、虚频、同位素、线性分子、失败 SCF 与单位测试 | 故意给负模式时显示虚频；不得用总模态数减 6 处理线性 H2 |

**阶段验收：** native 小分子频率正确，G16/ORCA 真执行频率，IR 功能按字段实际可用性开放。没有经过单独验证的热化学自由能不进入 v1 默认结果。

## v0.6.0：DFT、基组与方法质量

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 6.01/3.02 | `dft/grid.py`; `build_grid(mol, radial_level, angular_level)->Grid` | 核对 Lebedev 权重、球面规则、Becke 分割、单位/原点平移；grid level 可记录 | 重叠分子与非对称 H2O 的积分/权重测试；网格从粗到细能量趋势有数据 |
| 6.02/6.01 | `dft/functionals.py`, `dft/fock.py`, `scf/dft.py`; `xc_energy_potential(density, grad, tau, spin)->XCResponse` | 校验 LDA/PBE/B3LYP/TPSS 的 E_xc 与 V_xc 导数、hybrid exact exchange、spin 情况；非完全实现方法从能力表隐藏 | 以数值导数和独立后端的同配置小分子对照；不以“SCF 收敛”证明泛函正确 |
| 6.03/6.01,6.02 | `tests/dft/test_grid_convergence.py`, `docs/science/dft_validation.md` | 对 H2O、一个开壳层和小有机分子，在至少三档 grid 下记录 E、梯度、SCF step/耗时 | 格点收敛表、容差依据和原始日志存在；差异过大时标实验性 |
| 6.04/3.10 | `basis/basis_data.py`, `basis/basis_set.py`, `integrals/`; `get_basis(name, element)->BasisSet` | 对 6-31G(d)、def2-SVP 与一个扩散基组逐元素核验指数/收缩/球-笛卡尔顺序；基组缺元素则拒绝 | 与可信基组库/独立程序对照函数数及积分对称性；不把别名当完整新基组 |
| 6.05/6.04 | `mol/symmetry.py`; `detect_point_group(mol,tol)->SymmetryInfo` | 仅做孤立分子点群元数据；旋转/平移容差，含同位素；周期晶胞不作已有能力 | H2O、苯、非对称分子在坐标变换下识别一致；不宣称积分加速 |
| 6.06/6.02 | `dft/functionals.py`, `backends/native.py`, `docs/methods/xc_registry.md` | ωB97X-D、M06-2X 分开研究公式/参数、色散版本、E_xc/V_xc、spin/梯度；未全通过不注册 native | 多分子/基组/grid 参考和数值导数均过门才开放；成熟后端可独立提供同名方法 |

**阶段验收：** 已有 native DFT 有可重复的 grid 收敛证据；新泛函未通过则不列 native v1 能力。6.04 与 6.01 可并行做轻量代码工作，真实对照计算串行。

## v0.7.0：桌面产品完整度

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 7.01/3.06 | `io/project.py`, `io/manifest.py`; `create/open/save_project(path: Path)->Project` | 版本化 `.calchem` 目录，原子写入；请求/结果/日志相对路径；崩溃恢复、旧项目迁移 | 保存→退出→重开保留 jobs/molecules/results；读写中断不损坏最后完整版本 |
| 7.02/7.01 | `gui/project_panel.py`, `gui/main_window.py`; `open_project(path: Path)->None` | 新建、打开、最近项目、导入 XYZ/GJF、保存；编辑原子表与视图双向同步 | 真实用户流程完成；无效原子/自旋行内错误，不崩溃 |
| 7.03/3.06,7.01 | `gui/job_panel.py`, `gui/worker.py`; `submit_job(request)->str`, `render_job(job)->None` | UI 只提交唯一 TaskService；队列状态、取消请求、重试、新 job ID；Qt 主线程更新 widget | GUI/CLI 同时发起任务也不并发；第二任务真实执行；取消不伪报 |
| 7.04/3.09,5.05 | `gui/results/{summary,orbital,geometry,frequency,log}_tab.py`; `set_result(result)->None` | 总能优先显示 total_energy；SCF 能另列；轨道/频率有数据才绘制；失败时不格式化 null | 无能量/失败 Result 可展示错误与日志；post-HF 不显示 SCF 为总能 |
| 7.05/7.03 | `gui/results/convergence_tab.py`; `set_history(iterations, energies)->None` | 仅真实后端有逐步能量才显示曲线；支持 CSV/PNG 导出 | 无历史数据时显示未提供，不推造线条 |
| 7.06/3.04 | `gui/settings.py`, `gui/diagnostics.py`; `apply_config(config)->None`, `run_doctor()->DoctorReport` | GUI 修改 executable/data root，检测依赖/版本/写权限，导出脱敏诊断 | 配置实际影响下一任务；无后端时 UI 可读、可改、可运行 native |
| 7.07/7.02 | `gui/molecule_view.py`; `set_molecule(mol)->None` | 现有硬阈值距离画键仅为显示推断，改用元素半径/可选 bond table，保持视图性能；不自动改量化输入 | 卤素/长键/非键近距离样例视觉无明显假键；中型分子交互可用 |
| 7.08/7.01–7.07 | `tests/gui/`, `docs/gui.md` | 窗口缩放、键盘/高 DPI、空状态、错误状态、项目重开、单 worker 与状态测试；按 UI spec 手工验收 | 仅 `import MainWindow` 不算 GUI 完成；干净 Windows 安装环境跑通全流程 |

**阶段验收：** 按 `04_UI_SPEC.md` 页面清单逐项操作，记录截图/屏幕状态、项目目录和实际 Result。各 tab 轻量开发可并行，但数据契约和公共 service 先稳定。

## v0.8.0：OPV 工作流与下游

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 8.01/4.04,7.01 | `workflows/engine.py`; `run_steps(steps: Sequence[Step], project: Project)->WorkflowResult` | 步骤图：准备→优化→单点→轨道/偶极；失败阻断子节点；每步独立 request/Result | 故意令优化失败，所有下游为 blocked，不能继续用初始几何假跑 |
| 8.02/8.01 | `workflows/reorganization.py`; `compute_lambda(energies: FourPointEnergies)->ReorganizationResult` | 分别计算中性/阳离子/阴离子两组几何下四能量，charge/spin/method/基组固定并写清 λ_h/λ_e 公式与单位 | 四个能量各有 job 和 geometry hash；公式由固定数字反算；缺一项不返回数值 |
| 8.03/8.01 | `workflows/batch.py`; `enqueue_batch(molecules: Sequence[MoleculeSpec], template: CalculationRequest)->Batch` | 批量只进同一串行队列，失败可继续且能断点恢复/导出结果索引 | 多个小任务顺序、峰值并发 1；重启后不重复已完成 job |
| 8.04/8.01 | `md/gromacs_io.py`, `workflows/gromacs.py`; `export_topology(mol, charges, force_field)->ExportedTopology` | 分离电荷与完整 force-field 参数；检查 atom types/键角/非键参数、力场版本/来源，明确单位 | GROMACS `grompp` 真读入；缺参数则抛错，不生成看似完整的 itp |
| 8.05/8.01–8.04 | `examples/opv/`, `docs/opv.md`, `tests/workflows/` | 使用一个可公开/有使用许可的中型 OPV fixture；完整流程、资源与耗时、失败原因记录 | native/外部后端实际能力如实报告；小分子通过不等于 PM6/ClFFCl 已验收 |

**阶段验收：** 一个中型体系给出可重复的 workflow 和每一步证据；GROMACS 仅在真实参数齐全时开放。一台机器上的 heavy 步骤一律串行。

## v0.9.0：工程、文档与发布候选

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 9.01/3.01–8.05 | `pyproject.toml`, `requirements/constraints-win.txt`, `.github/workflows/ci.yml` | 依赖版本固定，Windows CI 跑纯 Python/快速原生基线、Ruff、公开 API mypy；外部许可项本机 gate | CI 实际触发并完成，不能仅有 yaml 文件；无 `pytest-xdist` heavy 并行 |
| 9.02/7.08 | `calchem.spec`, `scripts/build_windows.ps1` | 干净 D/E 盘 venv 打包 one-folder；控制 TEMP/work/dist；明确数据文件/Qt binding/hiddenimports | 不依赖开发机 conda 的 GUI/CLI 启动；发布 ZIP 的 SHA-256 与版本文件一致 |
| 9.03/9.02 | `tests/release/`, `scripts/verify_release.ps1` | ZIP 解压到含空格/中文路径；无网络、无 Gaussian/ORCA、只读数据目录、缺资源文件、卸载/替换验证 | 真 Windows 用户环境启动 native；缺外部 binary 不影响 native；不以“EXE 进程存在 5 秒”替代功能验收 |
| 9.04/3.14,8.05 | `README.md`, `docs/{api,cli,gui,backends,science,release}/`, `CHANGELOG.md` | 删除未实测的 GPU/泛函/大分子宣传；方法级能力与限制表、安装/配置/诊断、示例项目 | 文档和 GUI 能力表与代码/验收一致；新用户照文档独立完成流程 |
| 9.05/9.01–9.04 | `RELEASE_ACCEPTANCE.md`; `collect_evidence()->ReleaseReport` | 所有模块 gate 的命令、环境、结果、日志/截图、已知限制和 block 原因列表 | 每条结果有证据；没有空勾选、恒真断言、无退出码的“通过” |
| 9.06/9.01,9.02 | `LICENSES/`, `docs/release/licensing.md`; `collect_licenses()->LicenseInventory` | 盘点 PyQt6/Qt/Matplotlib/PyInstaller/NumPy 等发布依赖的许可证和通知；依据实际发布方式核对 PyQt6 GPLv3/商业许可选择；商业后端只记录外部路径 | 对外分发前许可证清单、发布方式和需要的源码/通知材料齐全；不因能打包就宣称可依法分发 |

**阶段验收：** Release Candidate 可供干净 Windows 本地验收；所有 CI/科学/GUI/打包报告齐全。

## v1.0：最终整体验收、发布

| ID/前置 | 文件与目标签名 | 实施动作 | 验收与假通过防线 |
|---|---|---|---|
| 10.01/9.05,9.06 | `scripts/run_acceptance.ps1`, `tests/release/`; `run_release_suite()->ExitCode` | 顺序执行数值、parser、真实可用后端、GUI 项目流、OPV/GROMACS、打包 smoke；收集机器与版本 | 任一必需 gate 未通过时非零退出；BLOCKED 项不当 PASS |
| 10.02/10.01 | `dist/CalChem/`, `release/manifest.json` | 固定发布文件、版本、SHA-256；移除本地临时/个人输入；不打包 G16/ORCA/xTB 本体 | 解压后可运行；签名/校验和一致；无敏感信息 |
| 10.03/10.02 | `RELEASE_ACCEPTANCE.md`, `docs/release.md` | 写最终 PASS/FAIL/BLOCKED，每个 backend 与方法单独列；说明尚未实现能力 | 用户仅看最终报告即可知道可用范围和复现方式 |

**终止条件：** `06_ACCEPTANCE_GATES.md` 的 v1 必需项真实通过，发布 ZIP 生成并检查完整性，交付报告自洽。若 REST 协议/商业安装等外部条件始终不可得，按已定范围禁用并标注 BLOCKED；不得因此停下其余模块开发，也不得宣称该后端已完成。
