// Libxc & native functionals
