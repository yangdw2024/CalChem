// Fischer-Almlof Model Hessian
