# CalChem Unified Quantum Chemistry Platform
__version__ = "1.0.0-alpha1"
