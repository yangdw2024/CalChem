"""Setup script for CalChem with automated Rust extension building and platform-tagged wheel generation."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys
from setuptools import setup
from setuptools.command.build_py import build_py as _build_py
from setuptools.dist import Distribution

ROOT = Path(__file__).resolve().parent

def build_rust_extension():
    """Builds the release calchem-py dynamic library if not already built."""
    ext = ".pyd" if sys.platform == "win32" else ".so"
    target_core = ROOT / "calchem" / f"_core{ext}"
    cargo_target = Path(os.environ.get("CARGO_TARGET_DIR", ROOT / "build_target")) / "release"
    
    cargo = os.environ.get("CALCHEM_CARGO", os.environ.get("CARGO", "cargo"))
    if not target_core.exists():
        built_dll = cargo_target / ("_core.dll" if sys.platform == "win32" else "libcalchem_py.so")
        if not built_dll.exists():
            built_dll = cargo_target / "calchem_py.dll"
        if not built_dll.exists():
            cmd = [cargo, "build", "--release", "--locked", "-p", "calchem-py"]
            subprocess.run(cmd, cwd=str(ROOT), check=True)
            if not built_dll.exists():
                built_dll = cargo_target / ("_core.dll" if sys.platform == "win32" else "libcalchem_py.so")
                if not built_dll.exists():
                    built_dll = cargo_target / "calchem_py.dll"
        if built_dll.exists():
            shutil.copy2(built_dll, target_core)

class BuildPyCommand(_build_py):
    def run(self):
        build_rust_extension()
        super().run()

class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True

setup(
    distclass=BinaryDistribution,
    cmdclass={"build_py": BuildPyCommand},
)
